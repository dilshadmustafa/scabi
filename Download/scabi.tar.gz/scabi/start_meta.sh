java -cp "dependency-jars/*":"*":. com.dilmus.dilshad.scabi.ms.MetaServer $1 $2 $3 $4
