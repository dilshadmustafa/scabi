java -cp "dependency-jars/*":"*":. com.dilmus.dilshad.scabi.cs.ComputeServer $1 $2 $3 $4 $5
