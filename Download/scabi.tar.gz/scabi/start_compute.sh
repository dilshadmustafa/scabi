java -cp "dependency-jars/*":"*":. com.dilmus.dilshad.scabi.cs.D2.ComputeServer_D2 $1 $2 $3 $4 $5
